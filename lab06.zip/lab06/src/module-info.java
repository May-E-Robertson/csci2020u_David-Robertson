module fxlab {
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;

    opens sample;
}